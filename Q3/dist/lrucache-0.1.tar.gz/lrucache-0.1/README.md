# Working

1. Creating cache
2. Creating cache elements
3. Pushing the elements in to the cache
4. Deleting particular element
5. Deleting expired elements in the cache

# Not working

1. Geolocation Distributed